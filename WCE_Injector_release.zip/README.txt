﻿WCE 注入器 - 使用说明
========================================

【运行步骤】
1. 先启动游戏 "Worst Class Ever"，进入游戏主菜单（不要卡在加载界面）
2. 双击运行 WCE_Injector.exe
3. 出现 "核心已加载并接受初始化" 字样即注入成功
4. 回到游戏，按 F2（或 Insert）打开菜单

【注意事项】
- 如果游戏是用管理员身份运行的，请右键 WCE_Injector.exe → 以管理员身份运行
- 需要 Windows 64 位系统
- 每次重开游戏后，都需要重新运行一次本程序
- 建议在进入房间/联机之前完成注入

【菜单按键】
- F2 / Insert ：打开或关闭菜单
- F7 ~ F13    ：切换菜单内各个页面

【备用方案】
若注入器无法使用，可手动把 DLL 文件夹里的 WorstClassEver.dll
复制到游戏安装目录（Worst Class Ever.exe 所在文件夹），再启动游戏。

【文件说明】
- WCE_Injector.exe        主程序（补丁已内嵌，双击即用）
- DLL\WorstClassEver.dll  备用核心 DLL
